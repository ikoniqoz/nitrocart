<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');
/**
 * NitroCart	NitroCart.net - A full featured shopping cart system for PyroCMS
 *
 * @author		Salvatore Bordonaro
 * @version		2.2.0.2050
 * @website		http://nitrocart.net
 *           	http://www.inspiredgroup.com.au
 *
 * @system		PyroCMS 2.2.x
 * http://au.api.fastway.org/v3/docs/index.html
 *
 */
class Fastway_core_2
{

    public function __get($var)
    {
        if (isset(get_instance()->$var))
        {
            return get_instance()->$var;
        }
    }


	protected $__api_key;
	protected $__url_ENDPOINTS = array(
			'list_franchises'=>'http://au.api.fastway.org/v3/psc/listrfs/',
			'calc_postage' =>'http://au.api.fastway.org/v3/psc/lookup/',
	);



	protected function setAPI($api)
	{
		$this->__api_key = $api;
	}

	protected function getAPI()
	{
		return $this->__api_key;
	}


	/**
	 * 
	 */
	protected function getEndpoint($type='calc_postage')
	{
		return $this->__url_ENDPOINTS[$type];
	}





	protected function _calc( $options, $shippable_items )
	{

		$this->setAPI( $options['apikey'] );

		$_total_cost = 0;
		$__count = 0;

		foreach($shippable_items as $item)
		{

			$__count++;

			$app = new FWUrlParam();
	
			$app->set('RFCode', $options['RFCode'] );

			if( trim($suburb) != '')
				$app->set('Suburb', $suburb );

			$app->set('DestPostcode', $options['to_zip'] );
			$app->set('WeightInKg', $item['weight'] );
			$app->set('LengthInCm', $item['length'] );
			$app->set('WidthInCm' , $item['width'] );
			$app->set('HeightInCm', $item['height'] );
			$app->set('AllowMultipleRegions', 'false' );
			$app->set('ShowBoxProduct', 'false' );
			$app->set('api_key', $options['apikey'] );

	        try
	        {
	        	$curl_url = $this->__url_ENDPOINTS['calc_postage'];
		        $_total_cost += ($item['qty'] * $this->calculate_postage( $app->get($curl_url) , $options  ) );

	        }
	        catch (Exception $e)
	        {
	            $msg = "oops: ".$e->getMessage();
	            $this->set_flashdata(JSONStatus::Error, $msg);
	            return FALSE;
	            //redirect('shop/cart');
	        }

	        //clear
	        $app = NULL;
		}

		//return $__count;
		return $_total_cost;
	}

    /**
     * [callAPService description]
     * @param  [type] $apparams    [description]
     * @param  string $error_redir [description]
     * @return [type]              [description]
     * $redir_on_error if false, will return 0
     */
    protected function calculate_postage( $url, $options=array(), $redir_on_error=TRUE )
    {

        $response = $this->getRemoteData( $url, (bool) $options['keepresponses'] );

        $returnArray = $this->analyseRespons( $response = array() );

        if($returnArray['status']=='success')
        {
        	//return cost and cont
        	return $returnArray['amount'];
        }

    	//handle error and receive message
    	if($redir_on_error)
    	{
    		redirect('shop/cart');
    	}

    	return 0;
    }


    protected function analyseRespons( $response = array() )
    {

        if (isset($results['result']['services'][0]['totalprice_frequent']))
        {

        	switch($options['package_type'])
        	{
        		case 'Either':     		
        		case 'Parcel':
        			//search for the parcel
        			foreach($results['result']['services'] as $service)
        			{
        				if($service['type'] == 'Parcel')
        				{
        					$amount =  $service['totalprice_frequent'];

					    	$returnArray = array(
					    		'amount'=>$amount,
					    		'status'=>'success'
					    	);     

					    	return $returnArray;
        				}
        			}     		
        		case 'Satchel':
        		 	$this->getService( $services , $type='Satchel' )
        			foreach($results['result']['services'] as $service)
        			{
        				if($service['type'] == 'Satchel')
        				{
        					$amount =  $service['totalprice_frequent'];

					    	$returnArray = array(
					    		'amount'=>$amount,
					    		'status'=>'success'
					    	); 

					    	return $returnArray;
        				}
        			}        		
        		default:   
        			//we found something else that should be ok
        			foreach($results['result']['services'] as $service)
        			{
        					$amount =  $service['totalprice_frequent'];

					    	$returnArray = array(
					    		'amount'=>$amount,
					    		'status'=>'success'
					    	); 

					    	return $returnArray;					    	
        			}  
        			break;
        	}

        }

    	$returnArray = array(
    		'amount'=>0,
    		'status'=>'error',
    		'message'=>'ER (SYS): Unknown',
    	);


        // Check for errors
        if (isset($results['error']))
        {
        	//SMR == Shipping Method Response
            //$this->session->set_flashdata( JSONStatus::Error , 'ER (SMR):'. $results['error'] );
	    	$returnArray['message'] = $results['error'];
        }

        return $returnArray;
    }

    private function getService( $services , $type='Satchel' )
    {

    	$returnArray = array(
    		'amount'=>0,
    		'status'=>'error',
    		'message'=>'None found',
    	);

		foreach($services as $service)
		{
			if( $service['type'] == $type )
			{
				$amount =  $service['totalprice_frequent'];

		    	$returnArray = array(
		    		'amount'=> $amount,
		    		'status'=> 'success'
		    	); 

		    	return $returnArray;
			}
		}   

		return $returnArray 

    }


    private function getRemoteData( $url, $options=array() )
	{
		
		//do a curl call request, and get contents
		$contents = $this->_do_CurlRequest($url);

		//store the results in a file if needed
		if($options['store_result'])
		{
			$this->_store_results($contents);
		}

		//currently only supports json but future we need to support the xml as well
		return $this->_formatResponse( $method, $options['format'] );
	}

	private function _do_CurlRequest($url)
	{
		$ch = curl_init();

		//$url = "http://au.api.fastway.org/v3/psc/lookup/MEL/SYD/200/5?api_key=fbb6f2f76be895dd580081dbab0fe803";
		curl_setopt($ch, CURLOPT_URL,$url);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);


		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$contents = curl_exec($ch);

		curl_close($ch);

		return $contents;
	}


	private function _store_results($contents)
	{
		$time = time();
		$time = substr($time,5);
		$date = new DateTime();
		$timestamp = $date->format("Y-m-d_") . $time;

		//stor the result for testing
		//$timestamp = date("Y-m-d__H.m.s.u");
		$path = SHARED_ADDONPATH . "modules/shop/bak/api_response/response_{$timestamp}_api.json";
		file_put_contents($path, $contents );
	}

	private function _formatResponse($contents, $method='json')
	{
		switch($method)
		{
			case 'csv':
				return 'Not implemented';
			case 'json':
			default:
				return json_decode($contents,TRUE);
				break;
		}

		return 'ER_Not implemented';
	}

}

/**
 * This allows for multi-value options by same key
 * where the original does not allow this
 */
if ( ! class_exists('FWUrlParam')) 
{
    class FWUrlParam
    {
        protected $params;
        protected $first;


        public function __construct()
        {
            $this->first = TRUE;
        }


        public function set($property, $value)
        {
            $this->_add($property, $value );
        }

       
        protected function _add($key,$value)
        {
            $this->params .= $this->first ? '?' : '&';
            $this->params .= "{$key}={$value}";
            $this->first = FALSE;
        }

        public function get($end_point='')
        {
            return $end_point.$this->params;
        }


        public function clear()
        {
            $this->first = TRUE;
            $this->params = '';
        }

    }
}