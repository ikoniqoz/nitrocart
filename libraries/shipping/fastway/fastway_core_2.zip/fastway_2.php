<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');
/**
 * NitroCart	NitroCart.net - A full featured shopping cart system for PyroCMS
 *
 * @author		Salvatore Bordonaro
 * @version		2.2.0.2050
 * @website		http://nitrocart.net
 *           	http://www.inspiredgroup.com.au
 *
 * @system		PyroCMS 2.2.x
 * http://au.api.fastway.org/v3/docs/index.html
 *
 */

require_once( dirname(__FILE__) . '/fastway_core_2.php');

class Fastway_ShippingMethod extends Fastway_core_2
{

	public function __construct()
	{
		parent::__construct();		
	}

	public function taxxed($shipping_cost)
	{
		return $shipping_cost * $this->tax_rate;
	}



	public function calc( $options, $items, $to_address = array() )
	{

		//set all the defaults now
		$options['to_zip'] = (isset($options['to_zip']))?$options['to_zip']:3000;
		$options['distcode'] = (isset($options['distcode']))?$options['distcode']:3000;
		$options['RFCode'] = (isset($options['RFCode']))?$options['RFCode']:'SYD';
		$options['packagetype'] = (isset($options['packagetype']))?$options['packagetype']:'Parcel';
		$options['apikey'] = (isset($options['apikey']))?$options['apikey']:'apikey';
		$options['suburb'] = '';


		$this->load->library('shop/packages_library');

		// Initialize the cost
		$_shippable_boxes = array();


		// Validate API before continuing
		if(! $this->validateAPIKey($options) && $this->validateOptions())
		{
			//handle this and cancel
			$this->session->set_flashdata(JSONStatus::Error,'Unable to Validate AustPost API Key. Shipping for this order has not been calculated');
			return FALSE;
		}


		if($options['usepackages'] == 'packages')
		{
			$this->packages_library->pack( $items );
			$_shippable_boxes = $this->packages_library->getShippableContainers();
		}
		else
		{
			$_shippable_boxes = $this->packages_library->getShippableContainersCartItems($items);
		}


		
		return ( count($_shippable_boxes) > 0 ) $this->_calc( $options, $_shippable_boxes) :  0 ;
	}


	public function form($options)
	{

		$a = array();
		$a['RFCODES'] = $this->getFranchiseForOZ($options['apikey']);
		if(count($a['RFCODES'] ) ==0)
		{
			$a['RFCODES'] = array('SYD'=>'Sydney');
		}
		$a['PACKAGE_TYPES'] = array(
				'Parcel'=>'Parcel',
				'Satchel'=>'Satchel',
				'Either'=>'Either (First Served)',
			);

		$a['KEEP_RESPONSES'] = array(
				0=>'Nah',
				1=>'Yeah',
			);


		return $a;
	}

}